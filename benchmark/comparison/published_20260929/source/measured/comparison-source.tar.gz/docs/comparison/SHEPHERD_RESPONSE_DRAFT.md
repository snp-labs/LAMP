# Shepherd response draft — incomplete experiments

Do not submit this as a completed comparison. No results have been invented.
Replace the bracketed sections only after the specified runs and fidelity review.

Dear shepherd,

Thank you for specifying the comparison needed to address this concern. We are
reconstructing zkMatrix independently from its published algorithms, including
the quadratic zero-knowledge construction and pairing-based verification
acceleration. We will identify the implementation and any differences in its
curve, SRS layout, batching and preprocessing.

The comparison will use the matrix dimensions and workloads of Section 7 on a
common machine. We will report setup separately, both commitment-inclusive and
precommitted proving costs, full verification costs, serialized communication,
and memory. Each completed configuration will have ten repetitions with raw
records and summary statistics.

[Insert verified same-host square and batch results, implementation revision,
hardware, exact security parameters, and discussion of measured trade-offs.]

For zkMaP, the artifact URL specified in Section 8.1 currently returns
“Repository not found.” Reimplementation also encountered discrepancies between
the matrix polynomial encoding, the scalar multiplication check in Section 4.4,
and the additive check in Appendix E Algorithm 2. Our executable diagnostics
demonstrate the exact equations being evaluated, including false-output
acceptance by those isolated equations; we have not treated these incomplete
checks as a sound matrix multiplication baseline.

[Insert author clarification and a faithful zkMaP implementation and results,
or discuss the documented reproduction limitation with the shepherd.]

The latest official LAMP revision was rechecked against the supplied parameter table. At K=128, rho=1/2, L=309 it compiles to 167,065 constraints, matching the paper count. We preserve its sampler, challenge ordering, circuit, crypto, and QA-link verification. Two isolated decoded square and batch smokes succeeded; these do not constitute the requested repeated comparison or prove every Section 7 workload condition. We will report full results only after common-host runs and confirmation of the paper setup and workload details. Historical b1 measurements are excluded.

Best regards,
The LAMP authors
