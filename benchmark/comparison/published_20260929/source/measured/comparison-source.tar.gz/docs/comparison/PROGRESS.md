# Comparison progress

Updated 2026-09-29 for official commit `e2d1cae`.

## Completed

- Migrated the independently reviewed zkMatrix implementation, batch proof and
  CLI, and zkMaP diagnostics into this latest official worktree. Imports use
  `example.com/lamp`.
- Added decoded direct verification to the zkMatrix batch codec test.
- Added opt-in LAMP full-online timing and canonical compressed LCP1 payload
  round-trip/reverification for square and batch paths. Official protocol and
  baseline CSV output are preserved.
- Added a source/binary/host-aware runner, strict raw-record aggregation,
  numeric zkMatrix CSV adapter, scheme filtering, q=1 path identity, and
  non-executing server plans.
- Targeted Go and Python fixtures pass.
- Exactly two isolated decoded full-proof smokes passed on the current source:
  square K7/L309 and batch q=2/K7/L309, GOMAXPROCS=10. See
  `DEVELOPMENT_RUNS.md` for raw artifact paths.

## Still required

- Root's independent review and common-host repetitions; the local smokes are
  functional evidence only.
- Adequate common server for the K7..13 square and q=1..10 batch grids.
- A fully specified and executable zkMaP protocol; diagnostics are excluded
  from performance comparison.
- A complete GPT-2 linked workload comparison and confirmed Section 7 setup
  provenance before claiming a full paper reproduction.

No full SOTA comparison, performance conclusion, or paper-ready table is
claimed.
