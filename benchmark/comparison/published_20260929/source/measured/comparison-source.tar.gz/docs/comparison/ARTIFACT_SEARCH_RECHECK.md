# Artifact search recheck — 2026-09-29

The package named `zkmatrix` on [Docs.rs](https://docs.rs/crate/zkmatrix/latest)
currently describes **DualMatrix**, its two-tier pairing commitments and four
subprotocols. This name alone does not identify an implementation of the
requested zkMatrix protocol. Its older source pages could not be retrieved in
this recheck; no conclusion about unseen older code is made.

The [DualMatrix authors’ publication](https://link.springer.com/article/10.1186/s42400-025-00462-6)
also states that its zkMatrix comparison used theoretical costs and measured
primitive timings because an implementation was unavailable to them. That is
historical evidence, not proof that no source exists today.

The supplied zkMatrix paper identifies its own BLS12-381 results as estimates
assuming 16-thread parallelism. Our implementation and measurements remain
explicitly independent, using BN254 and Go. We have not relabelled DualMatrix
code or its measurements as zkMatrix.

For zkMaP, the linked author artifact still returned 404 in the current check.
The original paper and the later thesis recheck are tracked separately in
`ZKMAP_SPEC_GAPS.md` and `ZKMAP_THESIS_RECHECK.md`. Equation diagnostics receive
no performance-baseline rows.
