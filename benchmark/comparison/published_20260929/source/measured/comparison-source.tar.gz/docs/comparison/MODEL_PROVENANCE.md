# Implementation provenance

This bounded migration and harness completion used Codex with `gpt-6-luna`, as
requested. No native agents were used.

The zkMatrix and zkMaP diagnostic packages were copied from the archived
preliminary checkout after review, then adapted to module path
`example.com/lamp`. The LAMP instrumentation was implemented against the
latest official source. Existing official circuit, crypto, protocol, sampler,
challenge order, QA-link algorithm, vendored gnark, and historical CSV schema
were preserved.

The older `../upstream` checkout and its measurements remain archived
preliminary work. Current smoke outputs, source audit, and comparison tooling
belong to this official `e2d1cae` worktree under `benchmark/comparison/`.
Tooling tests and local smokes establish implementation behavior only; they do
not imply author validation, security review, a faithful zkMaP baseline, or a
complete paper comparison.
