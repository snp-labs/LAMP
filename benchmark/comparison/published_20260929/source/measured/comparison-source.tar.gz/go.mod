module example.com/lamp

go 1.25.6

require (
	github.com/consensys/gnark v0.14.0
	github.com/consensys/gnark-crypto v0.19.3-0.20260210233638-4abc1c162a65
)

require (
	github.com/bits-and-blooms/bitset v1.24.4 // indirect
	github.com/blang/semver/v4 v4.0.0 // indirect
	github.com/fxamacker/cbor/v2 v2.9.0 // indirect
	github.com/google/pprof v0.0.0-20260202012954-cb029daf43ef // indirect
	github.com/mattn/go-colorable v0.1.14 // indirect; indirectbrew update
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/ronanh/intcomp v1.1.1 // indirect
	github.com/rs/zerolog v1.34.0 // indirect
	github.com/x448/float16 v0.8.4 // indirect
	golang.org/x/crypto v0.48.0
	golang.org/x/sync v0.19.0 // indirect
	golang.org/x/sys v0.41.0 // indirect
)

replace github.com/consensys/gnark => ./lib/gnark
